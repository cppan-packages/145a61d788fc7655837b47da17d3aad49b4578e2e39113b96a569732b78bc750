//
// Created by Damitha on 5/12/2018.
//

#ifndef MORFICONVERT_IDENTIFYMORFI_H
#define MORFICONVERT_IDENTIFYMORFI_H

#include <iostream>
#include <string>

namespace IdentifyMorfi {
    //Identify the data type of a given file
    std::string identify(std::string path);
};

#endif //MORFICONVERT_IDENTIFYMORFI_H
